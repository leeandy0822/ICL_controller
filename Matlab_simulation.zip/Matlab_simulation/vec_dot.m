function c = vec_dot(a, b)
    c = a'*b ;
end
