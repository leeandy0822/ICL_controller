function A_inv = distribution_inv(A)
    
    % body frame center = (0, 0) 


    A_inv = pinv(A);
end
