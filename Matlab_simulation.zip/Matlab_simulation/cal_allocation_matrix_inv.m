function M_inv = cal_allocation_matrix_inv(M)
    M_inv = inv(M);
end
